<!--
	Nama	: Yosepri Disyandro Berutu
	NIM		: 11318066
	Kelas	: 31TI2
-->
<html>
<head>
	<title></title>
</head>
<body>
	<form action="LoginProcess.php" method="post">
		<input type="text" name="username" placeholder="username"><br>
		<input type="password" name="password" placeholder="password"><br>
		<input type="submit" name="submit" value="Login">
	</form>
</body>
</html>