<?php
$user->lihat_job();

?>