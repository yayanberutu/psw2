<?php
	$grafik = imagecreate(200, 600);
	$biru = ImageColorAllocate($grafik, 0,0,255);
	$hitam = ageColorAllocate ($grafik, 0,0,0);
	$counter;
	for ($counter=0 ; $counter <200; $counter++){
		
	}

?>