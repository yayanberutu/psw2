<?php
	define("PI", 3.14);
	$r = 1.4;
	$volume = (4/3) * PI * $r * $r * $r;
	echo "$volume<br>";

?>