<!--
Nama : Yosepri Disyandro Berutu
NIM : 11318066
Kelas : 31TI2
-->
<!--end footer -->
	</td>
</tr>
</table>
<hr>
<div id="footer">
	@11318066 | UTS PSW II 2018/2019 | PEMILU 2019
</div>
</body>
</html>