<!-- 
	Nama	: Hasoloan Davinson Hamonangan Hutapea
	NIM		: 11318015
	Kelas	: 31TI 1 
-->

<table width="200">
<tr>
	<td class="menu_item"> <a href="index.php">Home</a></td>
</tr>
<tr>
	<td class="menu_item">
		<a href="display.php">Informasi Pemilu</a>
	</td>
</tr>
<tr>
	<td class="menu_item">
		<a href="index.php?viewLogin">Login</a>
	</td>
</tr>

</table>