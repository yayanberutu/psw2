<!-- 
	Nama	: Hasoloan Davinson Hamonangan Hutapea
	NIM		: 11318015
	Kelas	: 31TI 1 
-->

<!--end footer -->
	</td>
</tr>
</table>
<hr>
<div id="footer">
	11318015 NIM | UTS PSW II 2018/2019 | PEMILU 2019
</div>
</body>
</html>