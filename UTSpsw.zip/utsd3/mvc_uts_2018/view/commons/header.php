<!-- 
	Nama	: Hasoloan Davinson Hamonangan Hutapea
	NIM		: 11318015
	Kelas	: 31TI 1 
-->

<html>
<head>
	<title>PEMILU 2019</title>
	<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<h1> Pemilu 2019</h1>
<hr>
<table>
<tr>
	<td class="menu_box">
		<?php require_once(dirname(__FILE__)."/menubar.php")?>
	</td>
	<td class="content">
<!--end header-->