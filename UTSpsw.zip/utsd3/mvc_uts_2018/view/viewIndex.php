<?php
require_once(dirname(__FILE__).'/commons/header.php');
?>

halo

<?php

if (isset($_GET['berhasil'])) {
	echo "berhasil";
}

?>

<?php
require_once(dirname(__FILE__).'/commons/footer.php');
?>