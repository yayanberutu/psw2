<?php
require_once "template/header.php";
require_once "koneksi.php";

$sql = "SELECT * from author";
$hasil = mysqli_query($conn, $sql);
?>

<!--Tabel Writer-->
			<br><br>
	    		<table class="table table-hover bg-info">
				  <caption>Daftar Penulis</caption>
				  <thead>
				    <tr>
				      <th scope="col">id</th>
				      <th scope="col">Nama Pertama</th>
				      <th scope="col">Last Name</th>
				      <th scope="col">email</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
				  		while ($row = mysqli_fetch_assoc($hasil)) {
				  	?>
				    <tr>
				      <th scope="row"><?= $row['id'];?></th>
				      <td><?= $row['first_name'];?></td>
				      <td><?= $row['last_name'];?></td>
				      <td><?= $row['e_mail'];?></td>
				    </tr>
				    <?php
				    	}
				    ?>
				  </tbody>
				</table>
				<a href="cetakpdf.php">Cetak Data</a>
		<!--Akhir tabel writer -->


<?php
mysqli_close($conn);
require_once "template/footer.php";
?>
	