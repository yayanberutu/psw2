<?php
require "phpfpdf/fpdf.php";
//instansiasi pdf dari class dan memberikan pengaturan halaman PDF
$pdf = new FPDF('l', 'mm', 'A5');
//buat halaman Baru
$pdf->AddPage();
//setting jenis font
$pdf->SetFont('Arial', 'B', 16);
//mencetak string
$pdf->Cell(190, 7,'TOKO BUKU GRAMEDIA');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(190, 7, 'Daftar penulis buku');

//memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7, '', 0,1);

$pdf->SetFont('Arial','B',10);
$pdf->Cell(20,6,'ID',1,0);
$pdf->Cell(85,6,'FIRST NAME',1,0);
$pdf->Cell(27,6,'LAST NAME',1,0);
$pdf->Cell(25,6,'EMAIL',1,1);

include 'koneksi.php';
$mahasiswa = mysqli_query($conn, "select * from author");
while ($row = mysqli_fetch_array($mahasiswa)){
    $pdf->Cell(20,6,$row['id'],1,0);
    $pdf->Cell(85,6,$row['first_name'],1,0);
    $pdf->Cell(27,6,$row['last_name'],1,0);
    $pdf->Cell(25,6,$row['e_mail'],1,1); 
}
$pdf->Output();
mysqli_close($conn);
?>
