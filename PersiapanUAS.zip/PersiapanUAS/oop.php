<?php
abstract class mahasiswa{
	protected $nama = "Palti";
	public $nim = "11318066";
	public $prodi = "D3 - TI";

	// function __construct(){
	// 	echo $this->nama . "<br>";
	// 	echo $this->nim . "<br>";
	// 	echo $this->prodi . "<br>";
	// }

	public function ubahnama($nama){
		$this->nama = $nama;
	}
	public function cetaknama(){
		echo $this->nama;
	}
}
class melva extends mahasiswa{

}
$mhs = new melva();

$mhs->ubahnama("Yosepri");
$mhs->cetakNama();

?> 