<?php
include_once '../../config/database.php';
include_once '../../model/vote.php';

$database = new Database();
$db = $database->getConnection();

$vote = new Vote($db);

$id = isset($_GET['id']) ? $_GET['id'] : die('ERROR: missing Mahasiswa ID.');


$vote->vote_home = $id;

if($vote->create($vote->vote_home)){
    header('Location: ../../index.php');
}else{
    echo "<div class='alert alert-danger'>Unable to create Mahasiswa</div>";
}