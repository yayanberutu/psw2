<?php  


include_once '../../config/database.php';
include_once '../../model/count.php';
include_once '../../model/vote.php';

$database = new Database();
$db = $database->getConnection();
$chart = new Count($db);
$vote = new Vote($db);
$total_rows = $vote->countAll();

$nilai1 = $chart->read1();
$nilai2 = $chart->read2();
$nilai3 = $chart->read3();

while ($row = $nilai1->fetch(PDO::FETCH_ASSOC)){
    extract($row);
    $A = 0 + ($count/$total_rows*360);
}
while ($row = $nilai2->fetch(PDO::FETCH_ASSOC)){
    extract($row);
    $AB = $A + ($count/$total_rows*360);
}
while ($row = $nilai3->fetch(PDO::FETCH_ASSOC)){
    extract($row);
    $B = $AB + ($count/$total_rows*360);
};
$myImage = imagecreate(400, 420);

$black = imagecolorallocate($myImage, 255, 255,255);
$red = imagecolorallocate($myImage, 229, 57, 53);
$green = imagecolorallocate($myImage, 67, 215, 71);
$blue = imagecolorallocate($myImage, 30, 136, 229);
$dark_red = imagecolorallocate($myImage, 183, 28, 28);
$dark_green = imagecolorallocate($myImage, 27, 160, 32);
$dark_blue = imagecolorallocate($myImage, 13, 71, 161);

for ($i = 220; $i >= 200; $i--) { 
    imagefilledarc($myImage, 200, $i, 400, 400, 0,$A, $dark_red, IMG_ARC_PIE);
    imagefilledarc($myImage, 200, $i, 400, 400,$A,$AB, $dark_green, IMG_ARC_PIE);
    imagefilledarc($myImage, 200, $i, 400, 400,$AB,$B, $dark_blue, IMG_ARC_PIE);
}
//draw a pie 
 ImageFilledArc($myImage, 200,200,400,400,0,$A, $red, IMG_ARC_PIE);  
 ImageFilledArc($myImage, 200,200,400,400,$A,$AB, $green, IMG_ARC_PIE);  
 ImageFilledArc($myImage, 200,200,400,400,$AB,$B, $blue, IMG_ARC_PIE);
   
 //output the image to the browser  
 header ("Content-type: image/png");  
 ImagePng($myImage);  
   
 //clean up after yourself  
 ImageDestroy($myImage);  