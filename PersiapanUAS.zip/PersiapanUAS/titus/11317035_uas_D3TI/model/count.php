<?php
class Count
{
// database connection and table name
private $connection;
private $table_name = "vvote";
// object properties
public $count_total;
public $count_home;

public function __construct($db)
{
    $this->connection = $db;
}

function readTop(){
    $query = "SELECT * FROM " .$this->table_name. " GROUP BY `count` DESC LIMIT 1";
    $statement = $this->connection->prepare($query);
    $statement->execute();
    
    return $statement;
}

function read1(){

    $query = "SELECT count FROM " .$this->table_name. " WHERE `home` = 'Tipe 36'";
    $statement = $this->connection->prepare($query);
    $statement->execute();
    
    return $statement;
}

function read2(){

    $query = "SELECT count FROM " .$this->table_name. " WHERE `home` = 'Tipe 45'";
    $statement = $this->connection->prepare($query);
    $statement->execute();
    
    return $statement;
}

function read3(){

    $query = "SELECT count FROM " .$this->table_name. " WHERE `home` = 'Tipe 72'";
    $statement = $this->connection->prepare($query);
    $statement->execute();
    
    return $statement;
}

}