<?php
class Vote
{
// database connection and table name
private $connection;
private $table_name = "vote";
// object properties
public $vote_id;
public $vote_home;
public $vote_time;

public function __construct($db)
{
    $this->connection = $db;
}

function create($id)
{
    date_default_timezone_set('Asia/Jakarta');
    $query = "INSERT INTO " . $this->table_name. " SET home=:home, time=:time";
    $statement = $this->connection->prepare($query);

    $this->home = $id;
    $this->time = date('Y-m-d H:i:s');
// bind values
    $statement->bindParam(":home", $this->home);
    $statement->bindParam(":time", $this->time);
    if ($statement->execute()) {
        return true;
    }

    return false;
}

function countAll(){
    $query = "SELECT id FROM " . $this->table_name;
    $statement = $this->connection->prepare($query);
    $statement->execute();
    $number_of_row = $statement->rowCount();
    
    return $number_of_row;
}

}