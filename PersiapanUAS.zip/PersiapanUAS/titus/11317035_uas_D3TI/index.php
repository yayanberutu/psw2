<!--
 Nama : Amsal Situmorang
 NIM  : 11317035
-->

<?php
	include_once 'config/database.php';
	include_once 'model/vote.php';
	include_once 'model/count.php';

	$database = new Database();
	$db = $database->getConnection();

	$voting = new Count($db);

	$statement = $voting->read1();


?>

<!DOCTYPE html>
<html>
    <head>
        <title>Aplikasi Home Voting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js>"></script>
    </head>
    <body>
		<div class="container">
			<br>
			<div class="row">
				<div class="col-sm-3 text-right">
					<img src="images/mamikos.png" class="img-responsive" alt="Mamikos" height="150" width="150">
				</div>
				<div class="col-sm-9 text-left">
					<h1>Mami <b>Takur</b> is looking for the best home.
					<br>Which one do you suggest?</h1><br><br><br>
				</div>
			</div>
			<div class="row text-center">
				<div class="col-sm-4">
					<img src="images/36.jpg" class="img-responsive" alt="Tipe 36" height="200" width="200">
					<br><br>
					<a href='view/vote/create_vote.php?id=Tipe 36' class="btn btn-success">
            		<span class='glyphicon glyphicon-list'></span>Tipe 36
            		</a>
					<br>
					<?php 
					$statementcount = $voting->readTop();
					while($coba = $statementcount->fetch(PDO::FETCH_ASSOC)){
						extract($coba);
						$cobaa = $count;
						$statement = $voting->read1();
						while($row = $statement->fetch(PDO::FETCH_ASSOC)){
							extract($row);
							if($cobaa == $count){
								echo '<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;';
							}
							echo "<b>{$count} vote(s)</b>";
						}
					}
					?>
				</div>
				<div class="col-sm-4">
					<img src="images/45.jpg" class="img-responsive" alt="Tipe 45" height="200" width="200">
					<br><br>
					<a href='view/vote/create_vote.php?id=Tipe 45' class="btn btn-primary">
            		<span class='glyphicon glyphicon-list'></span>Tipe 45
            		</a>
					<br><?php 
					$statementcount = $voting->readTop();
					while($coba = $statementcount->fetch(PDO::FETCH_ASSOC)){
						extract($coba);
						$cobaa = $count;
						$statement = $voting->read2();
						while($row = $statement->fetch(PDO::FETCH_ASSOC)){
							extract($row);
							if($cobaa == $count){
								echo '<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;';
							echo "<b>{$count} vote(s)</b>";
							}else{
								echo "<b>{$count} vote(s)</b>";
							}
						}
					}
					?>
				</div>
				<div class="col-sm-4">
					<img src="images/72.jpg" class="img-responsive" alt="Tipe 72" height="200" width="200">
					<br><br>
					<a href='view/vote/create_vote.php?id=Tipe 72' class="btn btn-danger">
            		<span class='glyphicon glyphicon-list'></span>Tipe 72
            		</a>
					<br>
					<?php 
					$statementcount = $voting->readTop();
					while($coba = $statementcount->fetch(PDO::FETCH_ASSOC)){
						extract($coba);
						$cobaa = $count;
						$statement = $voting->read3();
						while($row = $statement->fetch(PDO::FETCH_ASSOC)){
							extract($row);
							if($cobaa == $count){
								echo '<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;';
							echo "<b>{$count} vote(s)</b>";
							}else{
								echo "<b>{$count} vote(s)</b>";
							}
						}
					}
					?>
				</div>
			</div>
			<br>
			<br>
			<div class="row text-center">
				<div class="col-sm-12">
					<a href="graph.php" class="btn btn-warning">Show Graph</a>
					<br><br>
					<h2>Your vote is meaningful for Mami <b>Takur</b>.</h2>
				</div>
			</div>
		</div>
    </body>
</html>