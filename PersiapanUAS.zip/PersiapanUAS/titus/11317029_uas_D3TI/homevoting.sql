/*
SQLyog Community v12.2.6 (32 bit)
MySQL - 5.6.24 : Database - homevoting
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`homevoting` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `homevoting`;

/*Table structure for table `vote` */

DROP TABLE IF EXISTS `vote`;

CREATE TABLE `vote` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `home` char(8) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `vote` */

insert  into `vote`(`id`,`home`,`time`) values 
(1,'Tipe 72','2018-05-16 11:07:21'),
(2,'Tipe 72','2018-05-16 11:07:30'),
(3,'Tipe 72','2018-05-16 11:07:37'),
(4,'Tipe 45','2018-05-16 11:07:53'),
(5,'Tipe 36','2018-05-16 11:08:08'),
(6,'Tipe 36','2018-05-16 11:08:22');

/*Table structure for table `vvote` */

DROP TABLE IF EXISTS `vvote`;

/*!50001 DROP VIEW IF EXISTS `vvote` */;
/*!50001 DROP TABLE IF EXISTS `vvote` */;

/*!50001 CREATE TABLE  `vvote`(
 `home` char(8) ,
 `count` bigint(21) 
)*/;

/*View structure for view vvote */

/*!50001 DROP TABLE IF EXISTS `vvote` */;
/*!50001 DROP VIEW IF EXISTS `vvote` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vvote` AS (select `vote`.`home` AS `home`,count(`vote`.`home`) AS `count` from `vote` group by `vote`.`home` order by count(`vote`.`home`) desc) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
