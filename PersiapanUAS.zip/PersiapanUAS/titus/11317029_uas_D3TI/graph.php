<!--
 Nama :
 NIM  :
-->
<!DOCTYPE html>
<html>
    <head>
        <title>The Best Home Voting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js>"></script>
    </head>
    <body>
		<div class="container">
			<br>
			<div class="row">
				<div class="col-sm-3 text-right">
					<img src="images/mamikos.png" class="img-responsive" alt="Mamikos" height="150" width="150">
				</div>
				<div class="col-sm-9 text-left">
					<h1>Mami <b>Takur</b> is looking for the best home.
					<br>Which one do you suggest?</h1><br><br><br>
				</div>
			</div>
			<div class="row text-center">
				<div class="col-sm-12">
					<img src="images/result.png" class="img-responsive" alt="HasilVote" height="350" width="500">
				</div>
			</div>
			<br>
			<br>
			<div class="row text-center">
				<div class="col-sm-12">
					<h2>Your vote is meaningful for Mami <b>Takur</b>.</h2>
				</div>
			</div>
		</div>
    </body>
</html>