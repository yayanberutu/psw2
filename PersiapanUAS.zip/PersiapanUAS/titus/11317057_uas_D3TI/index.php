<!--
 Nama : Dwi Putri Anatasya Sibarani
 NIM  : 11317057
-->

<!DOCTYPE html>
<html>
    <head>
        <title>Aplikasi Home Voting</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/bootstrap.min.js>"></script>
    </head>
    <body>
		<div class="container">
			<br>
			<div class="row">
				<div class="col-sm-3 text-right">
					<img src="images/mamikos.png" class="img-responsive" alt="Mamikos" height="150" width="150">
				</div>
				<div class="col-sm-9 text-left">
					<h1>Mami <b>Takur</b> is looking for the best home.
					<br>Which one do you suggest?</h1><br><br><br>
				</div>
			</div>
			<div class="row text-center">
				<div class="col-sm-4">
					<img src="images/36.jpg" class="img-responsive" alt="Tipe 36" height="200" width="200">
					<br><br>
					<button type="submit" name="vote-home" value="36" class="btn btn-success">
					<a href="index.php" class="btn btn-default" data-dismiss="vote"><h2 font-color="white">Type 36</h2></a></button>
					<br>
					<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;
					<b>3 vote(s)</b>
				</div>
				<div class="col-sm-4">
					<img src="images/45.jpg" class="img-responsive" alt="Tipe 45" height="200" width="200">
					<br><br>
					<button type="submit" name="vote-home" value="45" class="btn btn-primary">
					<a href="index.php" class="btn btn-default" data-dismiss="vvote"><h2>Tipe 45</h2></a></button>
					<br><img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;
					<b>2 vote(s)</b>
				</div>
				<div class="col-sm-4">
					<img src="images/72.jpg" class="img-responsive" alt="Tipe 72" height="200" width="200">
					<br><br>
					<button type="submit" name="vote-home" value="72" class="btn btn-danger">
					<a href="index.php" class="btn btn-default" data-dismiss="vvote"><h2>Tipe 72</h2></a></button>
					<br>
					<img src="images/star.png" class="img-responsive" alt="Best" height="20px">&nbsp;
					<b>4 vote(s)</b>
				</div>
			</div>
			<br>
			<br>
			<div class="row text-center">
				<div class="col-sm-12">
					<a href="graph.php" class="btn btn-warning">Show Graph</a>
					<br><br>
					<h2>Your vote is meaningful for Mami <b>Takur</b>.</h2>
				</div>
			</div>
		</div>
    </body>
</html>