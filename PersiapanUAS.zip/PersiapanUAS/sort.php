<?php
// $arr = array(2 , 1, 5, 4 , 11);
$arr = array(
	'0' => 2015 ,
	'1' => 2016 ,
	'2' => 2015 ,
	'3' => 2016 ,
	'4' => 2017,
	'5' => 2017,
	'6' => 2018,
	'7' => 2017
);
sort($arr);
// foreach ($arr as $key => $value) {
// 	echo $key . " " . $value . "<br>";
// }
global $temp; $temp = $arr[0];
$jlh = count($arr);
// echo $jlh . "<br>";
for($i=0; $i<$jlh; $i++){
	if ($i == 0) {
		echo $temp . "<br>";
	}
	if(($i != 0) && $temp != $arr[$i]){
		$temp = $arr[$i];
		echo $temp. "<br>";
	}
}


?>